<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Text
$_['text_subject']  = '%s - كلمة المرور الجديدة';
$_['text_greeting'] = 'كلمة المرور الجديدة التي تم طلبها من %s.';
$_['text_password'] = 'تم تغيير كلمة المرور الى:';
