<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title'] = 'معلومات';

// Text
$_['text_contact']  = 'اتصل بنا';
$_['text_sitemap']  = 'خريطة الموقع';