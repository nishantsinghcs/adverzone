<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

$_['heading_title']     = 'على متجرنا في آيباي - eBay';