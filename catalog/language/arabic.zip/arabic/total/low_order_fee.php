<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

$_['text_low_order_fee'] = 'رسوم مخفّضة';