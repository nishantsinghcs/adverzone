<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

$_['text_credit']   = 'رصيد المتجر';
$_['text_order_id'] = 'رقم الطلب : #%s';