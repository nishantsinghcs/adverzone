<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title'] = 'استخدم قسيمة التخفيض';

// Text
$_['text_success']  = 'تم قبول خصم قسيمة التخفيض !';

// Entry
$_['entry_coupon']  = 'الرجاء ادخال رمز قسيمة التخفيض';

// Error
$_['error_coupon']  = 'تحذير: رمز القسيمة خاطيء, أو انتهى أو تم استخدام الحد الأقصى للقسيمة!';
$_['error_empty']   = 'تحذير: الرجاء ادخال رمز قسيمة التخفيض !';