<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title'] = 'استخدم قسائم الهدايا';

// Text
$_['text_success']  = 'تم قبول خصم قسيمة الهدايا !';

// Entry
$_['entry_voucher'] = 'الرجاء ادخال رمز قسيمة الهدايا';

// Error
$_['error_voucher'] = 'تحذير: رمز القسيمة خاطيء, أو انتهى أو تم استخدام الحد الأقصى للقسيمة!';
$_['error_empty']   = 'تحذير: الرجاء ادخال رمز قسيمة الهدايا !';