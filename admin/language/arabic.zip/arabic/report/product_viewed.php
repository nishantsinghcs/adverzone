<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title']  = 'تقرير عن المنتجات التي تم مشاهدتها';

// Text
$_['text_list']        = 'قائمة';
$_['text_success']     = 'تم التعديل !';

// Column
$_['column_name']    = 'اسم المنتج';
$_['column_model']   = 'النوع';
$_['column_viewed']  = 'عدد المشاهدات';
$_['column_percent'] = 'نسبة مئوية';

// Error
$_['error_permission'] = 'تحذير: انت لا تمتلك صلاحيات التعديل!';