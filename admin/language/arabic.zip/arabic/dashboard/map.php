<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title'] = 'الاحصائيات حسب خريطة العالم';

$_['text_order']    = 'الطلبات';
$_['text_sale']     = 'المبيعات';