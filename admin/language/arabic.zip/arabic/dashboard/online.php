<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title'] = 'المتواجدون الآن';

// Text
$_['text_view']     = 'المزيد ...';