<?php
// Heading
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title']    = 'نسخة احتياطية / استعادة';

// Text
$_['text_backup']      = 'عمل نسخة احتياطية';
$_['text_success']     = 'تم تصدير قاعدة البيانات بنجاح !';
$_['text_list']        = 'قائمة';

// Entry
$_['entry_restore']    = 'تحميل :';
$_['entry_backup']     = 'نسخة احتياطية :';

// Error
$_['error_permission'] = 'تحذير : أنت لا تمتلك صلاحيات التعديل !';
$_['error_backup']     = 'تحذير : يجب اختيار جدول واحد على الأقل !';
$_['error_empty']      = 'تحذير : الملف الذي قمت باختياره فارغ !';